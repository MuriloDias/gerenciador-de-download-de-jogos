import { Component } from '@angular/core';

@Component({
  selector: 'app-games',
  templateUrl: './games.component.html',
  styleUrls: ['./games.component.css']
})
export class GamesComponent {
  //Substitui a lista com os jogos
  gamesList = "Lista dos Jogos a ser substituida";

}
